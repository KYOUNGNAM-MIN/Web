function val(){
  if(frm.password.value == ""){
    alert("비밀번호를 입력해주세요.");
    frm.password.focus();
    return false;
  }
  if(frm.confirmpassword.value == ""){
    alert("비밀번호 확인란을 입력해주세요.");
    return false;
  }
  if(frm.confirmpassword.value != frm.password.value){
    alert("비밀번호와 비밀번호 확인값이 일치하지 않습니다.");
    return false;
  }
  return true;
}
